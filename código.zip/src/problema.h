/*
 * problema.h
 *
 *  Created on: 08/10/2020
 *
 */

#ifndef PROBLEMA_H_
#define PROBLEMA_H_

#include "mem_structs.h"

int xor(int a, int b);
void funcion(INDIVIDUO *p);

#endif /* PROBLEMA_H */
